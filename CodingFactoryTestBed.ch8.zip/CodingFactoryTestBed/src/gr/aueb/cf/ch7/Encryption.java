package gr.aueb.cf.ch7;

import java.util.Scanner;

public class Encryption {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter the text to encrypt: ");
        String input = in.nextLine();

        String encryptedText = encrypt(input);

        System.out.println("Encrypted Text: " + encryptedText);
    }

    public static String encrypt(String input) {
        char[] chars = input.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            chars[i]++;
        }
        return new String(chars);
    }

}
