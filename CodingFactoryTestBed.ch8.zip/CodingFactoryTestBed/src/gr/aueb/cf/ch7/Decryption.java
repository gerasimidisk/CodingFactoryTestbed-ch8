package gr.aueb.cf.ch7;

import java.util.Scanner;

public class Decryption {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the text to decrypt: ");
        String input = scanner.nextLine();

        String decryptedText = decrypt(input);

        System.out.println("Decrypted Text: " + decryptedText);
    }

    public static String decrypt(String input) {
        char[] chars = input.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            chars[i]--;
        }
        return new String(chars);
    }

}
