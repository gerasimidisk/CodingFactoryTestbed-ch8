package gr.aueb.cf.ch5;

import java.util.Scanner;

public class MenuApp {

    static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        int n = 0;
        int result = 0;
        int choice = 0;

        while (true) {          //Μέσα στη main: While και if για τις περιπτώσεις και καλούμε printMenu, getUserChoice και getResult.
            printMenu();
            choice = getUserChoice();

            if (choice < 1 || choice > 6) {
                System.out.println("Λάθος Επιλογή");
                continue;
            }

            if (choice == 6) {
                System.out.println("Έξοδος");
                break;
            }

            System.out.println("Δώστε αριθμό για αστεράκια");
            n = in.nextInt();
            result = getResult(choice, n);
            System.out.println();
        }

    }

    public static void printMenu() {                            //Το Menu
        System.out.println("1. Εμφάνισε n αστεράκια οριζόντια");
        System.out.println("2. Εμφάνισε n αστεράκια κάθετα");
        System.out.println("3. Εμφάνισε n γραμμές με n αστεράκια");
        System.out.println("4. Εμφάνισε n γραμμές με αστεράκια 1-n");
        System.out.println("5. Εμφάνισε n γραμμές με αστεράκια n-1");
        System.out.println("6. Έξοδος από το πρόγραμμα");
        System.out.println("Δώσε επιλογή:");
    }

    public static int getUserChoice() {return in.nextInt();}        //Οι μέθοδοι για κάθε περίπτωση.
    public static int starsHorizontal(int n) {
        if (n == 0) {
            return 1;
        }
        System.out.print("*");
        return n + starsHorizontal(n-1);
    }
        public static int starsVertical ( int n){
           if(n == 0) {
               return 1;
            }
            System.out.println("*");
            return n + starsVertical(n-1);
        }
        public static int starsHorVer ( int n) {
//            for (int i = 1; i <= n; i++) {
//                for (int j = 1; j <= n; j++) {
//                    System.out.print("*");
//                }
//                System.out.println();
//                return n;
            if (n == 0) {
                return 1;
            }
            System.out.println("*");
            return n * starsHorVer(n-1);
        }

            public static int stars1toN(int n) {
//                for (int i = 1; i <= n; i++) {
//                    for (int j = 1; j <= i; j++) {
//                        System.out.print("*");
//                    }
//                    System.out.println();
//                }
//                return n;
                if (n == 0) {
                    return 1;
                }                                           //Δεν τα κατάφερα με τις μεθόδους.`
                System.out.print("*");
                return n * starsHorizontal(1 - n);
            }
            public static int starsNto1 ( int n){
//                for (int i = 1; i <= n; i++) {
//                    for (int j = n; j >= i; j--) {
//                        System.out.print("*");
//                    }
//                    System.out.println();
//                }
//                return n;
                if (n == 0) {
                    return 1;
                } return n-1 * starsHorizontal(n);
            }

            public static int getResult ( int choice, int n){
                int result = 0;                         //Σε switch case καλούμε τις παραπάνω μεθόδους για το αποτέλεσμα.

                switch (choice) {
                    case 1:
                        result = starsHorizontal(n);
                        break;
                    case 2:
                        result = starsVertical(n);
                        break;
                    case 3:
                        result = starsHorVer(n);
                        break;
                    case 4:
                        result = stars1toN(n);
                        break;
                    case 5:
                        result = starsNto1(n);
                        break;
                }
                return result;


            }

}

