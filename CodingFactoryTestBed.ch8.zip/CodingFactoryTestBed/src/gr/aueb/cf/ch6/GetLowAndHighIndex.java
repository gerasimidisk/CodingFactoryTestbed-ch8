package gr.aueb.cf.ch6;

public class GetLowAndHighIndex {

    public static void main(String[] args) {
        int[] arr = {0, 1, 4, 4, 4, 6, 7, 8, 8, 8, 8, 8};
        int key = 8;

        int[] result = getLowAndHighIndexOf(arr, key);

        System.out.println("Low Index: " + result[0]);
        System.out.println("High Index: " + result[1]);

        if (result[0] != -1 && result[1] != -1) {
            System.out.println("Key is present in the array.");
            System.out.println("Values with key " + key + " from position " + result[0] + " to " + result[1] + ":");
            for (int i = result[0]; i <= result[1]; i++) {
                System.out.print(arr[i] + " ");
            }
        } else {
            System.out.println("Key is not present in the array.");
        }
    }

    public static int[] getLowAndHighIndexOf(int[] arr, int key) {
        int[] result = {-1, -1};

        // Find low index
        result[0] = findLowIndex(arr, key);

        // Find high index
        result[1] = findHighIndex(arr, key);

        return result;
    }

    private static int findLowIndex(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == key) {
                result = mid;
                high = mid - 1; // Move left to find a lower index
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return result;
    }

    private static int findHighIndex(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;
        int result = -1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (arr[mid] == key) {
                result = mid;
                low = mid + 1; // Move right to find a higher index
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return result;
    }


}

