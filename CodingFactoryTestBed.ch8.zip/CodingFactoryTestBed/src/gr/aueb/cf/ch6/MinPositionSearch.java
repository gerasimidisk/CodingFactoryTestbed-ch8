package gr.aueb.cf.ch6;

/**
 * Finds the seconds minimum position of an el in an array.
 */
public class MinPositionSearch {

    public static void main(String[] args) {

        int[] arr = {1, 8, 7, 11, 19, 4, 2, 12};
        //printArray(arr);
        System.out.println();

        int secondMinPosition = getSecondMinPosition(arr,0,7);
        System.out.println("Second Minimum Position " + secondMinPosition);
    }

    /**
     * Prints the elements of an array.
     *
     * @param arr   the source array.
     */
    public static void printArray(int[] arr) {
        if (arr == null) return;

        for (int el : arr) {
            System.out.print(el + " ");
        }
    }

    public static void printArray(int[] arr, int low, int high) {
        if (arr == null) return;
        if (low < 0 || high > arr.length - 1) return;
        if (low > high) return;

        for (int i = low; i <= high; i++) {
            System.out.print(arr[i] + " ");
        }
    }
    public static int getMaxPosition(int[] array, int low, int high) {
        int maxPosition = 0;            //Καλούμε πάλι τη getMax.
        for (int i = 0; i < (array.length - 1); i++) {
            if (array[i + 1] > array[maxPosition]) {
                maxPosition = i + 1;
            }
        }
        return maxPosition + 1;
    }

    public static int getSecondMinPosition(int[] array, int low, int high) {
        printArray(array,low,high);
        int firstMinPosition = 0;       //Αρχικοποιούμε τη firstMin.

        for (int i = 0; i<(array.length-1); i++){
            if (array[i+1] < array[firstMinPosition]){
                firstMinPosition = i + 1 ;
            }
        }

        int secondMinPosition = getMaxPosition(array, low, high);

        for (int i = 0; i < (array.length); i++) {
            if (array[secondMinPosition] > array[firstMinPosition] && array[i] < array[secondMinPosition]
            && array[i] != array[firstMinPosition]) {
                secondMinPosition = i;
            }
        } return secondMinPosition + 1;
    }


}