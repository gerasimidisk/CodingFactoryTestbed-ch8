package gr.aueb.cf.ch6;

/**
 * Demonstrates a search method of the max position
 * of an array and returns the position with the max el value.
 */
public class GetMaxPositionElement {

    public static void main(String[] args) {
        int[] arr = {1, 8, 7, 11, 19, 4, 2, 12};
        //printArray(arr);
        System.out.println();

        int maxPosition = getMaxPosition(arr, 0, 7);
        System.out.println("Max Position " + maxPosition);
    }

    /**
     * Prints the elements of an array.
     *
     * @param arr   the source array.
     */


    public static void printArray(int[] arr) {
        if (arr == null) return;

        for (int el : arr) {
            System.out.print(el + " ");
        }
    }

    /**
     * Prints the elements of an array in a region
     * defined from 'low' index to 'high' index.
     *
     * @param arr       the source array.
     * @param low       the 'from' index.
     * @param high      the 'to' index.
     */
    public static void printArray(int[] arr, int low, int high) {
        if (arr == null) return;                        //Ελέγχουμε με if.
        if (low < 0 || high > arr.length - 1) return;
        if (low > high) return;

        for (int i = low; i <= high; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static int getMaxPosition(int[] array, int low, int high) {
        printArray(array, low, high);
        int maxPosition = 0;
        for (int i = 0; i < (array.length - 1); i++) {
            if (array[i + 1] > array[maxPosition]) {
                maxPosition = i + 1;
            }
        }
        return maxPosition + 1;  //Για να είναι readable καθότι ο χρήστης δε γνωρίζει απαραίτητα για τη θέση 0.
    }

}
