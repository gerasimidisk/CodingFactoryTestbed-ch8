package gr.aueb.cf.ch6;

import java.util.Arrays;
import java.util.Scanner;


    public class LotteryFilter {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter 6 integers from 1 to 49:");

            int[] numbers = new int[6];
            for (int i = 0; i < 6; i++) {
                System.out.print("Enter number " + (i + 1) + ": ");
                numbers[i] = scanner.nextInt();

                // Check if the entered number is within the valid range
                if (numbers[i] < 1 || numbers[i] > 49) {
                    System.out.println("Please enter numbers between 1 and 49.");
                    return;
                }
            }

            // Check filters
            if (!checkEvenOddCount(numbers) || !checkConsecutiveNumbers(numbers) ||
                    !checkSameLastDigitCount(numbers) || !checkSameTenCount(numbers)) {
                System.out.println("The entered numbers do not pass the filters.");
            } else {
                System.out.println("Congratulations! The entered numbers pass all the filters.");
            }
        }

        // Predicate: No more than three even numbers and three odd numbers
        public static boolean checkEvenOddCount(int[] numbers) {
            long evenCount = Arrays.stream(numbers).filter(num -> num % 2 == 0).count();
            long oddCount = Arrays.stream(numbers).filter(num -> num % 2 != 0).count();

            return evenCount <= 3 && oddCount <= 3;
        }

        // Predicate: No more than three consecutive numbers
        public static boolean checkConsecutiveNumbers(int[] numbers) {
            Arrays.sort(numbers);

            for (int i = 0; i < numbers.length - 2; i++) {
                if (numbers[i] + 1 == numbers[i + 1] && numbers[i] + 2 == numbers[i + 2]) {
                    return false;
                }
            }

            return true;
        }

        // Predicate: No more than three numbers with the same last digit
        public static boolean checkSameLastDigitCount(int[] numbers) {
            Arrays.sort(numbers);

            for (int i = 0; i < numbers.length - 2; i++) {
                if (numbers[i] % 10 == numbers[i + 1] % 10 && numbers[i] % 10 == numbers[i + 2] % 10) {
                    return false;
                }
            }

            return true;
        }

        // Predicate: No more than three numbers in the same ten
        public static boolean checkSameTenCount(int[] numbers) {
            Arrays.sort(numbers);

            for (int i = 0; i < numbers.length - 2; i++) {
                if (numbers[i] / 10 == numbers[i + 1] / 10 && numbers[i] / 10 == numbers[i + 2] / 10) {
                    return false;
                }
            }

            return true;
        }
    }


