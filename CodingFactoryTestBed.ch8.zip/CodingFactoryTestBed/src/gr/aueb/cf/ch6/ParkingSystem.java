package gr.aueb.cf.ch6;

import java.util.Arrays;

    public class ParkingSystem {

        public static int getMaxCarsParkedAtSameTime(int[][] arr) {
            int n = arr.length * 2;
            int[][] timeTable = new int[n][2];

            // Create a time table with arrival and departure times
            for (int i = 0; i < n; i += 2) {
                timeTable[i][0] = arr[i / 2][0]; // Arrival time
                timeTable[i][1] = 1; // Mark as arrival
                timeTable[i + 1][0] = arr[i / 2][1]; // Departure time
                timeTable[i + 1][1] = 0; // Mark as departure
            }

            // Sort the time table based on time
            Arrays.sort(timeTable, (a, b) -> a[0] - b[0]);

            // Calculate the maximum number of cars parked at the same time
            int maxCarsParked = 0;
            int currentCarsParked = 0;

            for (int i = 0; i < n; i++) {
                if (timeTable[i][1] == 1) {
                    // Arrival
                    currentCarsParked++;
                    maxCarsParked = Math.max(maxCarsParked, currentCarsParked);
                } else {
                    // Departure
                    currentCarsParked--;
                }
            }

            return maxCarsParked;
        }

        public static void main(String[] args) {
            int[][] arr = {{1012, 1136}, {1317, 1417}, {1015, 1020}};

            int maxCarsParked = getMaxCarsParkedAtSameTime(arr);

            System.out.println("Maximum number of cars parked at the same time: " + maxCarsParked);
        }
    }

