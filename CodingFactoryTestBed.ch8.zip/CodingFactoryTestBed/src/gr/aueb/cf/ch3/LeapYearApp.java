package gr.aueb.cf.ch3;

import java.util.Scanner;

public class LeapYearApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int year;
        boolean isLeap = false;


        while (true) {                                         //while - do για να μπει στη μέθοδο αναζήτησης
            System.out.println("Please type a year");
            year = scanner.nextInt();

            isLeap = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);   //Σύμφωνα με την οδηγία στο pdf.

            if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) {     //if για έλεγχο στις περιπτώσεις δίσεκτου.
                isLeap = true;
                System.out.println("Correct! Year is leap!");
                System.out.println("Thanks for using our app!");
                break;                             //Για να μην με ξαναβάλει στη while.
            } else {
                System.out.println("Incorrect. Please try again");

            }
        }
    }
}

// Στην προσπάθειά μου να κάνω nested την if, δεν κατάφερα
//να αποτυπώσω την περίπτωση του % 400 κι έτσι την έκανα ολογράφως.
// Υποθέτω ότι γι'αυτό κιτρινίζει.
//Θα ήθελα παρακαλώ μια υπόδειξη του πώς γίνεται nested. Ευχαριστώ.



