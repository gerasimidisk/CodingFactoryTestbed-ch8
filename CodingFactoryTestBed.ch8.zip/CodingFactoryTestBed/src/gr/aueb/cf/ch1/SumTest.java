package gr.aueb.cf.ch1;

import java.util.Scanner;

public class SumTest {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int num1 = 10;
        int num2 = 7;
        int sum = 0;

        sum = num1 + num2;

        System.out.println("Το αποτέλεσμα της πρόσθεσης είναι ίσο με: " + sum);
    }
}
