package gr.aueb.cf.ch4;

import java.util.Scanner;

/**
 * Εκτυπώνει n οριζόντια αστεράκια όπου ο χρήστης δίνει τον αριθμό.
 */
public class HorizontalNApp {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);      //Διαβάζουμε με Scanner στο stdin.
        int inputStar = 0;

        System.out.println("Please insert number of stars");
        inputStar = in.nextInt();

        for (int i = 1; i <= inputStar; i++) {
            System.out.print("*");             //Print ώστε να εκτυπωθούν οριζόντια αστεράκια
        }

        System.out.println();                  //Μια αλλαγή σειράς ώστε να μην είναι κολλημένα τα αστεράκια με το μήνυμα.
        System.out.println("Number of stars: " + inputStar);




    }
}
