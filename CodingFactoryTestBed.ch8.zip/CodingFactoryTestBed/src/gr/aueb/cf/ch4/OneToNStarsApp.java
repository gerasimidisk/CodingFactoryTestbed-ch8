package gr.aueb.cf.ch4;

import java.util.Scanner;

/**
 * Διαβάζει από 1 έως n αστεράκια που θέτει ο χρήστης.
 */
public class OneToNStarsApp {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);  //Διαβάζουμε με Scanner τη μεταβλητή n που θα δώσει ο χρήστης.
        int n = 0;

        System.out.println("Please insert number of stars");
        n = in.nextInt();

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {   //Το εσωτερικό for ελέγχεται από το i του εξωτερικού όσο το εξωτερικό είναι n.
                System.out.print("*");
            }
            System.out.println();   //Println για να είναι διακριτά τα αστεράκια.
        }
    }
}