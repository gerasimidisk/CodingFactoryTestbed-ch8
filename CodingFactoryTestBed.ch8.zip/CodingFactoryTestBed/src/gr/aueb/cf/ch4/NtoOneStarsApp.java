package gr.aueb.cf.ch4;

import java.util.Scanner;

public class NtoOneStarsApp {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = 0;

        System.out.println("Please insert number of stars");
        n = in.nextInt();

        for (int i = 1; i <= n; i++) {
            for (int j = n; j >= i; j--) {   //Στο εσωτερικό for, το j ξεκινάει από n και μειώνεται σε κάθε επανάληψη έως το 1.
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
