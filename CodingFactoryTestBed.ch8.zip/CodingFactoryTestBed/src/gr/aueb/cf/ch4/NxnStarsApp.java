package gr.aueb.cf.ch4;

import java.util.Scanner;

/**
 * Υπολογίζει το γινόμενο n x n που δίνει ο χρήστης.
 */
public class NxnStarsApp {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a = 0;
        int b = 0;
        int result = 1;        //Αρχικοποίηση στο 1 γιατί δεν υπάρχει γινόμενο στο 0.


        System.out.println("Please insert two ints");
        a = in.nextInt();
        b = in.nextInt();

        for (int i = 1; i <= a * b; i++) {
            result = a * b;                 //Το αποτέλεσμα (result) πρέπει να είναι το γινόμενο των μεταβλητών a * b
            System.out.print("*");
        }

        System.out.println();
        System.out.printf("Stars' number of %d * %d = %d", a, b, result);
    }

}
