package gr.aueb.cf.ch4;

import java.util.Scanner;

/**
 * Εκτυπώνει n κάθετα αστεράκια όπου ο χρήστης δίνει τον αριθμό.
 */
public class VerticalNStarsApp {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = 0;

        System.out.println("Please insert number of stars");
        n = in.nextInt();

        for (int i = 1; i <= n; i++) {
            System.out.println("*");          //Println ώστε να εκτυπωθούν κάθετα αστεράκια.
        }

        System.out.println();
        System.out.println("Number of stars " + n);

    }
}
